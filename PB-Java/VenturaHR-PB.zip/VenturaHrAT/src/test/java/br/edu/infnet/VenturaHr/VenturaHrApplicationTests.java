package br.edu.infnet.VenturaHr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VenturaHrApplicationTests {

	@Test
	void contextLoads() {
	}

}
