package br.edu.infnet.VenturaHr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VenturaHrApplication {

	public static void main(String[] args) {
		SpringApplication.run(VenturaHrApplication.class, args);
	}

}
