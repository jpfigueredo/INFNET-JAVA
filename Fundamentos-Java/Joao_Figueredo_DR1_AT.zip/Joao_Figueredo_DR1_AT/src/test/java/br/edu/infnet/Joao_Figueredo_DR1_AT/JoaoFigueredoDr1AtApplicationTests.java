package br.edu.infnet.Joao_Figueredo_DR1_AT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoaoFigueredoDr1AtApplicationTests {

	@Test
	void contextLoads() {
	}

}
