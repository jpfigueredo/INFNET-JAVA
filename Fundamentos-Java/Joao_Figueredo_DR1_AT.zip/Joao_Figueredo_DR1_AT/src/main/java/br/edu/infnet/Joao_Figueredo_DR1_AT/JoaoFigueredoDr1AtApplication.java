package br.edu.infnet.Joao_Figueredo_DR1_AT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoaoFigueredoDr1AtApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoaoFigueredoDr1AtApplication.class, args);
	}

}
