package br.edu.infnet.appPedido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppPedidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
