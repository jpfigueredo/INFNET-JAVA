package br.infnet.edu.poo.tp1;

class SeguroVeiculo {
    private Veiculo veiculo;
    private double valorSeguro;
    private double franquia;
    
    private String modelo;
    
    public double getValorSeguro() {
        return valorSeguro;
    }

    public void setValorSeguro(double valorSeguro) {
        this.valorSeguro = valorSeguro;
    }

    public double getFranquia() {
        return franquia;
    }

    public void setFranquia(double franquia) {
        this.franquia = franquia;
    }
    
    // veiculo.getMarcaModelo = new modelo;
    
    
    
}
