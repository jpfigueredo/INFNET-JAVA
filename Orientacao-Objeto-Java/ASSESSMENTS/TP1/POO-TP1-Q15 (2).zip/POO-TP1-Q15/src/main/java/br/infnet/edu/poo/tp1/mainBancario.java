package br.infnet.edu.poo.tp1;

public class mainBancario {

    public static void main(String[] args) {
        
        ContaCliente conta = new ContaCliente("Daniel", "daniel.batatinha123@yahool.com", 965391830, 300.0);
        System.out.println(conta);
    
    }
    
}
