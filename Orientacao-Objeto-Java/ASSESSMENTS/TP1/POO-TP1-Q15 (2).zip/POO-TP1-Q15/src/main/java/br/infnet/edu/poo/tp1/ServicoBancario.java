package br.infnet.edu.poo.tp1;

public class ServicoBancario {
    private Cliente cliente;
    private Funcionario funcionario;
    private Emprestimo emprestimo;
    private SeguroVeiculo seguroVeiculo;
}
